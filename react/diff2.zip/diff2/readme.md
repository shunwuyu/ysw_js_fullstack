1 jsx(react-jsx-plugin)->vnode(createElement)->DOM(render)

2 Component(render的第三种方式，react-jsx vnode.tag function Counter ) -> 标签化组件->Counter(extends)->Component类->render(jsx)->reactDOM.render()

3 响应式setState() 