import createElement from './create-element.js'
import Component from './component.js'
export default {
  createElement,
  Component
}