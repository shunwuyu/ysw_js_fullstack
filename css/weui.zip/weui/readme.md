# WEUI 微信统一Web界面 

## 表单  cells
> 在小程序中，使用WEUI做快速开发，让小程序更快
- MVVM
  用户登录模块 
  username password 
  Model? user Object
  value="{{user.username}}"
  value="{{user.passsword}}"
  V wxml weui 写form 
  VM? 两者的结合体  View 模板，待compile 跟随model
  model 数据绑定 bindinput bindtap 值改变 状态改变
  VM代表那一刻的状态。
  
